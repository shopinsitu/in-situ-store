IN SITU homepage update

This update avoids using Replit Agent.

Files included:
1. src/NewApp.tsx — adds the revised homepage.
2. src/main.tsx — switches the site entry point to the revised homepage wrapper.

In Replit:
1. Open the Files panel.
2. Go to artifacts > in-situ-store > src.
3. Upload NewApp.tsx into that src folder.
4. Open the existing main.tsx and replace it with the included main.tsx.
5. Click Run / Preview. No Replit Agent is required.
6. If it looks right, use the Git tool to commit and push:
   Homepage hero and mobile refinement

What changes:
- Removes the separate homepage header bar.
- Navigation sits directly over the hero image.
- Removes Visit from the homepage.
- Enlarges and centers the IN SITU wordmark.
- Uses Furniture · Objects · Furnishings.
- Uses “Unusual & considered things.”
- Reworks Shop Categories into the looser editorial/cutout-style composition.
- Simplifies mobile to Menu + Bag.
- Gives New Arrivals a cleaner horizontal mobile browse.
- Existing Shop, Product, Collections, About, cart, search, and filters continue to use the current App.tsx.

Revert:
Change src/main.tsx back to importing App from './App' and render <App />.
